import json
import re
import uuid
from datetime import date, datetime, timedelta
from pathlib import Path


DATA_DIR = Path("data")
DATA_FILE = DATA_DIR / "library_data.json"


def ensure_storage():
    DATA_DIR.mkdir(exist_ok=True)
    if not DATA_FILE.exists():
        save_data(_default_data())


def _default_data():
    return {
        "books": [],
        "members": [],
        "transactions": [],
    }


def load_data():
    ensure_storage()
    with DATA_FILE.open("r", encoding="utf-8") as file_handle:
        return json.load(file_handle)


def save_data(data):
    DATA_DIR.mkdir(exist_ok=True)
    with DATA_FILE.open("w", encoding="utf-8") as file_handle:
        json.dump(data, file_handle, indent=2)


def slugify(value):
    cleaned = re.sub(r"[^a-zA-Z0-9]+", "-", value.strip().lower()).strip("-")
    return cleaned or "item"


def _build_id(prefix, value):
    return f"{prefix}-{slugify(value)}-{uuid.uuid4().hex[:6]}"


def list_books():
    return load_data()["books"]


def list_members():
    return load_data()["members"]


def list_transactions():
    transactions = load_data()["transactions"]
    return sorted(transactions, key=lambda item: item["issued_on"], reverse=True)


def add_book(title, author, category, isbn, copies):
    data = load_data()
    normalized_isbn = isbn.strip()
    if normalized_isbn and any(book["isbn"].lower() == normalized_isbn.lower() for book in data["books"]):
        raise ValueError("A book with this ISBN already exists.")

    total_copies = max(int(copies), 1)
    book = {
        "book_id": _build_id("book", title),
        "title": title.strip(),
        "author": author.strip(),
        "category": category.strip(),
        "isbn": normalized_isbn,
        "total_copies": total_copies,
        "available_copies": total_copies,
        "created_at": _timestamp(),
    }
    data["books"].append(book)
    save_data(data)
    return book


def add_member(name, email, phone):
    data = load_data()
    normalized_email = email.strip().lower()
    if normalized_email and any(member["email"].lower() == normalized_email for member in data["members"]):
        raise ValueError("A member with this email already exists.")

    member = {
        "member_id": _build_id("member", name),
        "name": name.strip(),
        "email": normalized_email,
        "phone": phone.strip(),
        "joined_on": _today(),
    }
    data["members"].append(member)
    save_data(data)
    return member


def issue_book(book_id, member_id, days=14):
    data = load_data()
    book = _find_by_id(data["books"], "book_id", book_id)
    member = _find_by_id(data["members"], "member_id", member_id)

    if not book:
        raise ValueError("Selected book was not found.")
    if not member:
        raise ValueError("Selected member was not found.")
    if book["available_copies"] <= 0:
        raise ValueError("No copies are currently available for this book.")
    if any(
        tx["book_id"] == book_id and tx["member_id"] == member_id and tx["status"] == "issued"
        for tx in data["transactions"]
    ):
        raise ValueError("This member already has this book issued.")

    transaction = {
        "transaction_id": _build_id("txn", f"{book_id}-{member_id}"),
        "book_id": book_id,
        "member_id": member_id,
        "book_title": book["title"],
        "member_name": member["name"],
        "issued_on": _today(),
        "due_on": (date.today() + timedelta(days=int(days))).isoformat(),
        "returned_on": "",
        "status": "issued",
    }

    book["available_copies"] -= 1
    data["transactions"].append(transaction)
    save_data(data)
    return transaction


def return_book(transaction_id):
    data = load_data()
    transaction = _find_by_id(data["transactions"], "transaction_id", transaction_id)
    if not transaction:
        raise ValueError("Selected transaction was not found.")
    if transaction["status"] == "returned":
        raise ValueError("This book has already been returned.")

    book = _find_by_id(data["books"], "book_id", transaction["book_id"])
    if not book:
        raise ValueError("Linked book record no longer exists.")

    transaction["status"] = "returned"
    transaction["returned_on"] = _today()
    book["available_copies"] = min(book["available_copies"] + 1, book["total_copies"])
    save_data(data)
    return transaction


def get_active_transactions():
    return [tx for tx in list_transactions() if tx["status"] == "issued"]


def get_overdue_transactions():
    today = date.today()
    overdue = []
    for transaction in get_active_transactions():
        if datetime.fromisoformat(transaction["due_on"]).date() < today:
            overdue.append(transaction)
    return overdue


def search_books(query):
    query_text = query.strip().lower()
    if not query_text:
        return list_books()

    matches = []
    for book in list_books():
        haystack = " ".join(
            [
                book["title"],
                book["author"],
                book["category"],
                book["isbn"],
            ]
        ).lower()
        if query_text in haystack:
            matches.append(book)
    return matches


def get_summary():
    books = list_books()
    members = list_members()
    transactions = list_transactions()
    active_transactions = [tx for tx in transactions if tx["status"] == "issued"]

    return {
        "total_titles": len(books),
        "total_members": len(members),
        "books_issued": len(active_transactions),
        "books_available": sum(book["available_copies"] for book in books),
        "overdue_books": len(get_overdue_transactions()),
    }


def _find_by_id(items, key, value):
    for item in items:
        if item[key] == value:
            return item
    return None


def _today():
    return date.today().isoformat()


def _timestamp():
    return datetime.now().isoformat(timespec="seconds")
