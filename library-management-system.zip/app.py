import pandas as pd
import streamlit as st

from backend import (
    add_book,
    add_member,
    ensure_storage,
    get_active_transactions,
    get_overdue_transactions,
    get_summary,
    issue_book,
    list_books,
    list_members,
    list_transactions,
    return_book,
    search_books,
)


st.set_page_config(page_title="Library Management System", page_icon="L", layout="wide")
ensure_storage()


def _book_options():
    return {
        f"{book['title']} by {book['author']} ({book['available_copies']}/{book['total_copies']} available)": book["book_id"]
        for book in list_books()
    }


def _member_options():
    return {f"{member['name']} ({member['email'] or member['phone'] or member['member_id']})": member["member_id"] for member in list_members()}


def _transaction_options():
    return {
        f"{tx['book_title']} -> {tx['member_name']} (due {tx['due_on']})": tx["transaction_id"]
        for tx in get_active_transactions()
    }


st.title("Library Management System")
st.caption("Manage books, members, and lending activity from one local dashboard.")

summary = get_summary()
metric_cols = st.columns(5)
metric_cols[0].metric("Titles", summary["total_titles"])
metric_cols[1].metric("Members", summary["total_members"])
metric_cols[2].metric("Issued", summary["books_issued"])
metric_cols[3].metric("Available Copies", summary["books_available"])
metric_cols[4].metric("Overdue", summary["overdue_books"])

dashboard_tab, books_tab, members_tab, circulation_tab = st.tabs(
    ["Dashboard", "Books", "Members", "Circulation"]
)

with dashboard_tab:
    st.subheader("Catalog Overview")
    search_query = st.text_input("Search books", placeholder="Search by title, author, category, or ISBN")
    books = search_books(search_query)
    if books:
        st.dataframe(pd.DataFrame(books), use_container_width=True, hide_index=True)
    else:
        st.info("No books match the current search.")

    recent_transactions = list_transactions()[:10]
    st.subheader("Recent Transactions")
    if recent_transactions:
        st.dataframe(pd.DataFrame(recent_transactions), use_container_width=True, hide_index=True)
    else:
        st.info("No circulation activity yet.")

    overdue = get_overdue_transactions()
    st.subheader("Overdue Books")
    if overdue:
        st.dataframe(pd.DataFrame(overdue), use_container_width=True, hide_index=True)
    else:
        st.success("No overdue books right now.")

with books_tab:
    st.subheader("Add Book")
    with st.form("add_book_form", clear_on_submit=True):
        title = st.text_input("Title")
        author = st.text_input("Author")
        category = st.text_input("Category")
        isbn = st.text_input("ISBN")
        copies = st.number_input("Number of Copies", min_value=1, step=1, value=1)
        add_book_submit = st.form_submit_button("Add Book")

    if add_book_submit:
        if not title.strip() or not author.strip() or not category.strip():
            st.error("Title, author, and category are required.")
        else:
            try:
                add_book(title, author, category, isbn, copies)
                st.success("Book added successfully.")
                st.rerun()
            except ValueError as error:
                st.error(str(error))

    st.subheader("Current Catalog")
    all_books = list_books()
    if all_books:
        st.dataframe(pd.DataFrame(all_books), use_container_width=True, hide_index=True)
    else:
        st.info("Add your first book to start building the catalog.")

with members_tab:
    st.subheader("Register Member")
    with st.form("add_member_form", clear_on_submit=True):
        member_name = st.text_input("Member Name")
        member_email = st.text_input("Email")
        member_phone = st.text_input("Phone")
        add_member_submit = st.form_submit_button("Add Member")

    if add_member_submit:
        if not member_name.strip():
            st.error("Member name is required.")
        else:
            try:
                add_member(member_name, member_email, member_phone)
                st.success("Member added successfully.")
                st.rerun()
            except ValueError as error:
                st.error(str(error))

    st.subheader("Member Directory")
    members = list_members()
    if members:
        st.dataframe(pd.DataFrame(members), use_container_width=True, hide_index=True)
    else:
        st.info("No members registered yet.")

with circulation_tab:
    left_col, right_col = st.columns(2)

    with left_col:
        st.subheader("Issue Book")
        book_choices = _book_options()
        member_choices = _member_options()
        if book_choices and member_choices:
            with st.form("issue_form"):
                selected_book = st.selectbox("Book", options=list(book_choices.keys()))
                selected_member = st.selectbox("Member", options=list(member_choices.keys()))
                issue_days = st.number_input("Loan Period (days)", min_value=1, max_value=60, value=14, step=1)
                issue_submit = st.form_submit_button("Issue Book")

            if issue_submit:
                try:
                    issue_book(book_choices[selected_book], member_choices[selected_member], issue_days)
                    st.success("Book issued successfully.")
                    st.rerun()
                except ValueError as error:
                    st.error(str(error))
        else:
            st.info("Add at least one book and one member before issuing books.")

    with right_col:
        st.subheader("Return Book")
        transaction_choices = _transaction_options()
        if transaction_choices:
            with st.form("return_form"):
                selected_transaction = st.selectbox("Issued Book", options=list(transaction_choices.keys()))
                return_submit = st.form_submit_button("Return Book")

            if return_submit:
                try:
                    return_book(transaction_choices[selected_transaction])
                    st.success("Book returned successfully.")
                    st.rerun()
                except ValueError as error:
                    st.error(str(error))
        else:
            st.info("There are no active issued books to return.")

    st.subheader("Active Loans")
    active_transactions = get_active_transactions()
    if active_transactions:
        st.dataframe(pd.DataFrame(active_transactions), use_container_width=True, hide_index=True)
    else:
        st.info("No active loans at the moment.")

    st.subheader("Full Transaction History")
    transactions = list_transactions()
    if transactions:
        st.dataframe(pd.DataFrame(transactions), use_container_width=True, hide_index=True)
    else:
        st.info("Transaction history will appear here after the first issue.")
